# Question 2 - JS assignment

A Pen created on CodePen.io. Original URL: [https://codepen.io/Complete-rel/pen/JjQZJro](https://codepen.io/Complete-rel/pen/JjQZJro).

This is my JavaScript assignment