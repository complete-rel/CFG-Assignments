# Question 1 - JS Assignment working

A Pen created on CodePen.io. Original URL: [https://codepen.io/Complete-rel/pen/WNqPbqX](https://codepen.io/Complete-rel/pen/WNqPbqX).

